# GrowPilot PWA
Modern Progressive Web App for tracking plant growth, watering, nutrients, and harvests.